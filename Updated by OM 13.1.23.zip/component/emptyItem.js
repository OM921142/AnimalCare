import * as React from "react";
import { Text } from "react-native";

export default function emptyItem({}) {
	return <Text></Text>;
}
