import WorkAllocation from "./WorkAllocationHome";
import FeedMenu from "./FeedMenu";
import AddAllocation from "./AddAllocation";
import FeedDetails from "./FeedDetails";

export { WorkAllocation, FeedMenu, AddAllocation, FeedDetails };
