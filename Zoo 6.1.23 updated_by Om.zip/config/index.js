import Colors from "./colors";
import Configs from "./Configs";
// import FakeData, {BIRDDATA} from "./fakeData";

// export { Colors, FakeData, BIRDDATA };

export { Colors, Configs };
