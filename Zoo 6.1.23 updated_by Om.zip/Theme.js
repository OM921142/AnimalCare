export default {
    primary: '#63c3a5'
}